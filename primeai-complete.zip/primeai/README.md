# PrimeAI - The Sharpest AI Assistant on the Web

![PrimeAI Logo](./public/logo.png)

A production-ready SaaS platform built with Next.js 14, featuring AI-powered chat, Stripe subscriptions, and a complete marketing suite.

## 🚀 Features

### Core Features
- ✨ **AI Chat Interface** - Intelligent conversations with context awareness
- 🔐 **Authentication** - Secure auth with Clerk (Email + Google OAuth)
- 💳 **Stripe Integration** - Complete subscription management
- 📊 **Usage Tracking** - Monitor message limits and usage
- 🎨 **Modern UI** - Built with TailwindCSS and shadcn/ui
- 📱 **Responsive Design** - Mobile-first, works on all devices

### Subscription Tiers
- **Free**: 20 messages per month
- **Monthly Pro**: $19/month - Unlimited messages
- **Annual Pro**: $190/year - Unlimited messages (save $38)

### Technical Features
- Next.js 14 App Router with TypeScript
- Server-side rendering and API routes
- PostgreSQL database with Prisma ORM
- Stripe webhooks for subscription management
- SEO optimized with sitemap and robots.txt
- WCAG AA accessibility compliant

## 📋 Prerequisites

Before you begin, ensure you have:
- Node.js 18+ installed
- npm or yarn package manager
- PostgreSQL database (we recommend Neon)
- Stripe account (test mode for development)
- Clerk account for authentication

## 🛠️ Installation

### 1. Clone and Install Dependencies

```bash
cd primeai
npm install
```

### 2. Set Up Environment Variables

Copy `.env.example` to `.env` and fill in your credentials:

```bash
cp .env.example .env
```

Required environment variables:

```env
# Database
DATABASE_URL="postgresql://user:password@host:5432/primeai?sslmode=require"

# Clerk Authentication
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_xxxxx
CLERK_SECRET_KEY=sk_test_xxxxx
NEXT_PUBLIC_CLERK_SIGN_IN_URL=/sign-in
NEXT_PUBLIC_CLERK_SIGN_UP_URL=/sign-up
NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL=/app
NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL=/app

# Stripe
STRIPE_SECRET_KEY=sk_test_xxxxx
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_xxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxx
STRIPE_PRICE_ID_MONTHLY=price_xxxxx
STRIPE_PRICE_ID_ANNUAL=price_xxxxx

# App Configuration
NEXT_PUBLIC_APP_URL=http://localhost:3000
ADMIN_USER_IDS=user_xxxxx

# OpenAI (Optional - for real AI responses)
OPENAI_API_KEY=sk-xxxxx
```

### 3. Set Up Database

```bash
# Generate Prisma client
npx prisma generate

# Run migrations
npx prisma migrate dev

# (Optional) Seed database
npx prisma db seed
```

### 4. Run Development Server

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

## 🔧 Configuration Guides

### Clerk Setup

1. Create account at [clerk.com](https://clerk.com)
2. Create new application
3. Enable Email and Google OAuth providers
4. Copy API keys to `.env`
5. Configure redirect URLs:
   - Sign-in: `/sign-in`
   - Sign-up: `/sign-up`
   - After sign-in: `/app`
   - After sign-up: `/app`

### Stripe Setup

1. Create account at [stripe.com](https://stripe.com)
2. Switch to Test mode
3. Create products:
   - **Monthly Pro**: $19/month recurring
   - **Annual Pro**: $190/year recurring
4. Copy Price IDs to `.env`
5. Set up webhook endpoint:
   - URL: `https://your-domain.com/api/webhooks/stripe`
   - Events: `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`
6. Copy webhook secret to `.env`
7. Configure Customer Portal:
   - Enable subscription management
   - Enable payment method updates
   - Set return URL: `https://your-domain.com/app/settings`

### Database Setup (Neon)

1. Create account at [neon.tech](https://neon.tech)
2. Create new project
3. Copy connection string
4. Add to `.env` as `DATABASE_URL`
5. Run migrations: `npx prisma migrate dev`

## 📁 Project Structure

```
primeai/
├── app/                    # Next.js app directory
│   ├── api/               # API routes
│   │   ├── chat/         # Chat endpoint
│   │   ├── checkout/     # Stripe checkout
│   │   ├── portal/       # Billing portal
│   │   ├── messages/     # Message history
│   │   ├── subscription/ # Subscription info
│   │   └── webhooks/     # Stripe webhooks
│   ├── app/              # Protected app pages
│   │   ├── page.tsx      # Chat interface
│   │   └── settings/     # User settings
│   ├── pricing/          # Pricing page
│   ├── privacy/          # Privacy policy
│   ├── terms/            # Terms of service
│   ├── refund/           # Refund policy
│   ├── layout.tsx        # Root layout
│   ├── page.tsx          # Landing page
│   ├── globals.css       # Global styles
│   ├── sitemap.ts        # SEO sitemap
│   └── robots.ts         # SEO robots
├── components/            # React components
│   ├── ui/               # shadcn/ui components
│   ├── navbar.tsx        # Navigation
│   └── footer.tsx        # Footer
├── lib/                   # Utility functions
│   ├── db.ts             # Prisma client
│   ├── stripe.ts         # Stripe utilities
│   ├── subscription.ts   # Subscription logic
│   └── utils.ts          # Helper functions
├── prisma/               # Database schema
│   └── schema.prisma     # Prisma schema
├── marketing/            # Marketing materials
│   ├── BRAND_GUIDELINES.md
│   ├── SOCIAL_MEDIA_ADS.md
│   ├── EMAIL_TEMPLATES.md
│   └── LAUNCH_COPY.md
├── public/               # Static assets
├── .env.example          # Environment template
├── middleware.ts         # Clerk middleware
├── next.config.js        # Next.js config
├── tailwind.config.ts    # Tailwind config
├── tsconfig.json         # TypeScript config
└── package.json          # Dependencies
```

## 🚢 Deployment

### Deploy to Vercel (Recommended)

1. Push code to GitHub
2. Import project in Vercel
3. Add environment variables
4. Deploy!

```bash
# Or use Vercel CLI
npm i -g vercel
vercel
```

### Environment Variables for Production

Update these in Vercel dashboard:
- Change Clerk URLs to production domain
- Use Stripe live keys
- Update `NEXT_PUBLIC_APP_URL`
- Set production `DATABASE_URL`

### Post-Deployment Checklist

- [ ] Test authentication flow
- [ ] Test subscription checkout
- [ ] Verify webhook endpoint
- [ ] Test chat functionality
- [ ] Check mobile responsiveness
- [ ] Verify SEO tags
- [ ] Test all legal pages
- [ ] Monitor error logs

## 🧪 Testing

### Manual Testing Checklist

**Authentication:**
- [ ] Sign up with email
- [ ] Sign up with Google
- [ ] Sign in with email
- [ ] Sign in with Google
- [ ] Sign out

**Free Tier:**
- [ ] Send messages (count should decrease)
- [ ] Reach limit (should show upgrade prompt)
- [ ] Wait for monthly reset

**Subscription:**
- [ ] Checkout flow (monthly)
- [ ] Checkout flow (annual)
- [ ] Verify unlimited messages
- [ ] Access billing portal
- [ ] Cancel subscription
- [ ] Reactivate subscription

**Chat Interface:**
- [ ] Send message
- [ ] Receive response
- [ ] View message history
- [ ] Copy message
- [ ] Scroll through long conversations

**Settings:**
- [ ] View account info
- [ ] View subscription status
- [ ] View usage statistics
- [ ] Manage billing

## 📊 Admin Features

### Admin Access

Set admin user IDs in `.env`:
```env
ADMIN_USER_IDS=user_xxxxx,user_yyyyy
```

### Admin Dashboard (Coming Soon)

Future admin features:
- User management
- Subscription analytics
- Usage monitoring
- Revenue tracking

## 🎨 Customization

### Branding

Update brand colors in `tailwind.config.ts` and `app/globals.css`:
- Primary: `#00D8FF` (Neon Blue)
- Secondary: `#00FF95` (Emerald Green)
- Background: `#0F1115` (Deep Charcoal)

### Content

Update content in:
- `app/page.tsx` - Landing page
- `app/pricing/page.tsx` - Pricing page
- `components/navbar.tsx` - Navigation
- `components/footer.tsx` - Footer

### AI Responses

Replace mock AI in `app/api/chat/route.ts` with real AI:

```typescript
// Example with OpenAI
import OpenAI from 'openai'

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
})

async function generateAIResponse(message: string): Promise<string> {
  const completion = await openai.chat.completions.create({
    model: "gpt-4",
    messages: [{ role: "user", content: message }],
  })
  
  return completion.choices[0].message.content || "No response"
}
```

## 📈 Marketing

### Included Marketing Materials

- **Brand Guidelines** - Complete brand identity guide
- **Social Media Ads** - Ready-to-use ad copy for all platforms
- **Email Templates** - 10 professional email templates
- **Launch Copy** - Product Hunt, Reddit, LinkedIn, Twitter

### SEO Optimization

Built-in SEO features:
- Dynamic meta tags
- Open Graph images
- Twitter cards
- Sitemap generation
- Robots.txt
- Structured data

## 🔒 Security

### Best Practices Implemented

- ✅ Environment variables for secrets
- ✅ Clerk authentication with middleware
- ✅ Stripe webhook signature verification
- ✅ SQL injection prevention (Prisma)
- ✅ XSS protection (React)
- ✅ CSRF protection (Next.js)
- ✅ Rate limiting (implement as needed)

### Additional Security Recommendations

1. Enable Vercel's DDoS protection
2. Set up monitoring and alerts
3. Regular dependency updates
4. Security headers in `next.config.js`
5. Implement rate limiting for API routes

## 🐛 Troubleshooting

### Common Issues

**Database Connection Error**
```bash
# Check DATABASE_URL format
# Ensure database is accessible
# Run: npx prisma db push
```

**Clerk Authentication Not Working**
```bash
# Verify API keys in .env
# Check redirect URLs in Clerk dashboard
# Ensure middleware.ts is configured
```

**Stripe Webhooks Failing**
```bash
# Verify webhook secret
# Check endpoint URL
# Test with Stripe CLI: stripe listen --forward-to localhost:3000/api/webhooks/stripe
```

**Build Errors**
```bash
# Clear cache
rm -rf .next
npm run build
```

## 📝 License

This project is licensed under the MIT License.

## 🤝 Support

For support:
- Email: support@primeai.app
- Documentation: [Link to docs]
- Issues: [GitHub Issues]

## 🎯 Roadmap

### Coming Soon
- [ ] Mobile apps (iOS/Android)
- [ ] Team collaboration features
- [ ] API access
- [ ] Custom AI personalities
- [ ] Advanced analytics
- [ ] Integrations (Slack, Discord, etc.)

### Future Enhancements
- [ ] Voice input/output
- [ ] File uploads
- [ ] Image generation
- [ ] Multi-language support
- [ ] White-label options

## 🙏 Acknowledgments

Built with:
- [Next.js](https://nextjs.org/)
- [Clerk](https://clerk.com/)
- [Stripe](https://stripe.com/)
- [Prisma](https://prisma.io/)
- [TailwindCSS](https://tailwindcss.com/)
- [shadcn/ui](https://ui.shadcn.com/)

---

**Made with ❤️ by the PrimeAI Team**

For questions or feedback, reach out at hello@primeai.app