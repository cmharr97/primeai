# PrimeAI Brand Guidelines

## Brand Identity

**Brand Name:** PrimeAI  
**Tagline:** "The Sharpest AI Assistant on the Web"  
**Domain:** primeai.app

## Brand Personality

- **Innovative:** Cutting-edge AI technology
- **Reliable:** Trustworthy and consistent
- **Modern:** Sleek and futuristic design
- **Accessible:** User-friendly and approachable
- **Professional:** High-quality service

## Color Palette

### Primary Colors
- **Deep Charcoal:** #0F1115 (Background)
- **Neon Blue:** #00D8FF (Primary accent)
- **Emerald Green:** #00FF95 (Secondary accent)
- **Pure White:** #FFFFFF (Text)

### Secondary Colors
- **Dark Gray:** #1A1A1A (Cards, surfaces)
- **Medium Gray:** #2A2A2A (Borders)
- **Light Gray:** #9CA3AF (Secondary text)

### Usage Guidelines
- Use Deep Charcoal as the primary background
- Neon Blue for primary CTAs and important elements
- Emerald Green for success states and secondary CTAs
- White for primary text and headings
- Create gradients using Blue → Green for premium features

## Typography

### Primary Font
**Inter** (Sans-serif)
- Headings: Bold (700)
- Body: Regular (400)
- Emphasis: Semibold (600)

### Font Sizes
- Hero Heading: 4rem (64px)
- H1: 3rem (48px)
- H2: 2rem (32px)
- H3: 1.5rem (24px)
- Body: 1rem (16px)
- Small: 0.875rem (14px)

## Logo Usage

### Logo Variations
1. **Full Logo:** Icon + "PrimeAI" text
2. **Icon Only:** Gradient square for small spaces
3. **Text Only:** "PrimeAI" with gradient

### Logo Construction
- Icon: 32x32px gradient square (Blue → Green)
- Rounded corners: 8px
- Text: Inter Bold, gradient fill

### Clear Space
Maintain minimum clear space of 16px around logo

### Don'ts
- Don't stretch or distort the logo
- Don't change the gradient colors
- Don't add effects or shadows
- Don't place on busy backgrounds

## Visual Style

### Design Elements
- **Glow Effects:** Subtle neon glow on hover states
- **Gradients:** Linear gradients from Blue to Green
- **Rounded Corners:** 8px for cards, 4px for buttons
- **Shadows:** Soft, subtle shadows for depth
- **Animations:** Smooth transitions (0.3s ease)

### UI Components
- **Buttons:** Gradient fill with glow effect
- **Cards:** Dark background with subtle border
- **Inputs:** Dark with light border, focus glow
- **Icons:** Line style, consistent stroke width

## Photography & Imagery

### Style Guidelines
- Modern, clean, professional
- High contrast with dark backgrounds
- Technology and innovation themes
- Diverse representation
- Minimal and focused compositions

### Image Treatment
- Subtle blue/green color overlay
- High contrast adjustments
- Sharp, crisp quality
- Consistent aspect ratios

## Voice & Tone

### Brand Voice
- **Confident:** We know our technology works
- **Friendly:** Approachable and helpful
- **Clear:** No jargon, easy to understand
- **Innovative:** Forward-thinking and modern

### Writing Style
- Use active voice
- Keep sentences concise
- Focus on benefits, not features
- Be conversational but professional
- Use "you" to address users

### Example Phrases
✅ "Experience the future of AI assistance"
✅ "Get instant, intelligent answers"
✅ "Your AI assistant, always ready"
❌ "Utilizing advanced algorithms"
❌ "Leveraging cutting-edge technology"

## Application Examples

### Website Headers
```
PrimeAI — The Sharpest AI Assistant on the Web
Experience the Future of AI Assistance
Get Instant, Intelligent Answers
```

### Call-to-Actions
```
Get Started Free
Try PrimeAI Now
Upgrade to Pro
Start Your Free Trial
```

### Feature Descriptions
```
Lightning Fast Responses
Secure & Private Conversations
Natural, Human-like Interactions
Always Learning, Always Improving
```

## Social Media Guidelines

### Profile Images
- Use full logo on dark background
- Maintain brand colors
- Ensure visibility at small sizes

### Cover Images
- Feature gradient backgrounds
- Include tagline
- Show product screenshots
- Maintain 16:9 aspect ratio

### Post Style
- Use brand colors in graphics
- Include logo watermark
- Consistent visual style
- High-quality images only

### Hashtags
#PrimeAI #AIAssistant #ArtificialIntelligence #TechInnovation #ProductivityTools

## Print Materials

### Business Cards
- Dark background
- Gradient logo
- Minimal information
- QR code to website

### Brochures
- Clean, modern layout
- Plenty of white space
- Feature screenshots
- Clear hierarchy

## Accessibility

### Color Contrast
- Ensure WCAG AA compliance
- Test all color combinations
- Provide sufficient contrast ratios

### Typography
- Minimum 16px for body text
- Clear hierarchy
- Adequate line spacing
- Readable font choices

## Brand Evolution

This brand guide is a living document. As PrimeAI grows, the brand may evolve while maintaining core identity elements. Any major changes should be documented and communicated to all stakeholders.

---

**Last Updated:** 2025
**Version:** 1.0