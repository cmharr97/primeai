# PrimeAI Email Templates

## 1. Welcome Email

**Subject:** Welcome to PrimeAI! 🚀 Your AI Assistant is Ready

**Preview Text:** Get started with your 20 free messages

**Body:**

---

Hi [First Name],

Welcome to PrimeAI! We're thrilled to have you join our community of intelligent users.

**Your account is ready to go:**
✅ 20 free messages per month
✅ Full access to our AI assistant
✅ Secure, private conversations
✅ Message history saved

**Getting Started is Easy:**

1. Visit your dashboard: [Dashboard Link]
2. Type your first question
3. Get instant, intelligent answers

**Need some inspiration? Try asking:**
- "Help me brainstorm ideas for [topic]"
- "Explain [concept] in simple terms"
- "Write a professional email about [subject]"
- "What are the best practices for [task]"

**Pro Tip:** The more context you provide, the better PrimeAI can help you!

Ready to experience the future of AI assistance?

[Start Chatting Now]

Questions? Just reply to this email - we're here to help!

Best regards,
The PrimeAI Team

P.S. Want unlimited messages? Check out our Pro plans starting at just $19/month. [View Pricing]

---

**Footer:**
PrimeAI | primeai.app
[Unsubscribe] | [Privacy Policy] | [Terms of Service]

---

## 2. Upgrade Prompt Email (After 15 Messages Used)

**Subject:** You're loving PrimeAI! ❤️ Upgrade for unlimited access

**Preview Text:** Only 5 messages left this month

**Body:**

---

Hi [First Name],

Great news - you're getting amazing value from PrimeAI! You've used 15 of your 20 free messages this month.

**Want to keep the momentum going?**

Upgrade to PrimeAI Pro and get:
✨ **Unlimited messages** - never run out
⚡ **Priority responses** - even faster answers
🎯 **Advanced features** - coming soon
💎 **Premium support** - we've got your back

**Special Offer: Save 20% on your first month**
Use code: UPGRADE20 at checkout

[Upgrade to Pro - $19/month] [Upgrade to Annual - $190/year (Save $38)]

**Still not sure?** Here's what our Pro users say:

"Upgrading was the best decision. I use PrimeAI every single day!" - Sarah J.

"The unlimited plan pays for itself in saved time." - Michael C.

"I can't imagine working without PrimeAI now." - Emily R.

[See All Plans]

Have questions? Reply to this email anytime.

Best,
The PrimeAI Team

---

**Footer:**
PrimeAI | primeai.app
[Unsubscribe] | [Privacy Policy]

---

## 3. Limit Reached Email

**Subject:** You've reached your free message limit 📊

**Preview Text:** Upgrade to continue using PrimeAI

**Body:**

---

Hi [First Name],

You've used all 20 of your free messages this month! 🎉

This shows PrimeAI is valuable to you - and we want to keep helping.

**Your options:**

**Option 1: Wait for Reset**
Your free messages reset on [Reset Date]. We'll send you a reminder!

**Option 2: Upgrade to Pro**
Get unlimited messages starting today.

[Upgrade Now - $19/month]

**Why upgrade?**
✅ Unlimited messages
✅ No more waiting
✅ Priority support
✅ Advanced features

**Limited Time: Get 30% off your first month**
Use code: UNLIMITED30

[Claim Your Discount]

**Not ready to upgrade?**
No problem! Your free messages will reset on [Reset Date], and we'll be here when you need us.

Questions? Just reply to this email.

Best regards,
The PrimeAI Team

---

**Footer:**
PrimeAI | primeai.app
[Unsubscribe] | [Privacy Policy]

---

## 4. Monthly Reset Notification

**Subject:** Your PrimeAI messages have reset! 🔄

**Preview Text:** 20 new messages are ready to use

**Body:**

---

Hi [First Name],

Good news! Your monthly message limit has reset.

**You now have:**
✅ 20 fresh messages
✅ Full access to PrimeAI
✅ All your conversation history

[Start Chatting Now]

**Make the most of your messages:**
- Ask complex questions that save you research time
- Get help with creative projects
- Solve problems faster
- Learn new concepts

**Want unlimited access?**
Upgrade to Pro and never worry about limits again.

[View Pro Plans]

Happy chatting!

The PrimeAI Team

---

**Footer:**
PrimeAI | primeai.app
[Unsubscribe] | [Privacy Policy]

---

## 5. Churn Prevention Email (Canceled Subscription)

**Subject:** We're sorry to see you go 😢 Can we help?

**Preview Text:** Your feedback matters to us

**Body:**

---

Hi [First Name],

We noticed you canceled your PrimeAI Pro subscription. We're sorry to see you go!

**Before you leave, we'd love to know:**
What could we have done better?

[Take 2-Minute Survey] (Get 1 month free)

**Common reasons & solutions:**

**"Too expensive"**
→ We offer a 50% student/educator discount
→ Annual plan saves you $38/year

**"Not using it enough"**
→ Try our free plan (20 messages/month)
→ Set reminders to use PrimeAI daily

**"Missing features"**
→ Tell us what you need - we're building new features monthly

**"Technical issues"**
→ Our support team can help immediately

[Talk to Support]

**Special Offer: Come Back for 50% Off**
Use code: COMEBACK50 for 50% off any plan for 3 months

[Reactivate Subscription]

Your subscription remains active until [End Date]. You can reactivate anytime before then to keep your conversation history.

We'd love to have you back!

Best regards,
The PrimeAI Team

P.S. Even if you don't return, we'd appreciate your feedback: [Quick Survey]

---

**Footer:**
PrimeAI | primeai.app
[Privacy Policy]

---

## 6. Win-Back Email (30 Days After Cancellation)

**Subject:** We miss you! Come back to PrimeAI 💙

**Preview Text:** Exclusive offer inside

**Body:**

---

Hi [First Name],

It's been a month since you left PrimeAI, and we miss you!

**A lot has changed:**
✨ New features added
⚡ Faster response times
🎯 Improved accuracy
💎 Better user interface

**Exclusive Win-Back Offer:**
**Get 60% off for 3 months**
Use code: WELCOME-BACK

That's just $7.60/month for unlimited messages!

[Claim Your Offer]

**What you've been missing:**
- [Feature 1 launched]
- [Feature 2 launched]
- [Improvement made]

**See what users are saying:**

"The new updates are incredible! So glad I came back." - Former user

"PrimeAI keeps getting better. Worth every penny." - Returning customer

**No commitment required:**
Cancel anytime. Your conversation history is still saved.

[Reactivate Now]

Questions? Reply to this email - we're here to help!

Best,
The PrimeAI Team

P.S. This offer expires in 7 days. Don't miss out!

---

**Footer:**
PrimeAI | primeai.app
[Unsubscribe] | [Privacy Policy]

---

## 7. Feature Announcement Email

**Subject:** 🎉 New Feature: [Feature Name] is here!

**Preview Text:** Check out what's new in PrimeAI

**Body:**

---

Hi [First Name],

Exciting news! We've just launched [Feature Name] in PrimeAI.

**What's new:**
[Feature description and benefits]

**How to use it:**
1. [Step 1]
2. [Step 2]
3. [Step 3]

[Try It Now]

**Why you'll love it:**
✅ [Benefit 1]
✅ [Benefit 2]
✅ [Benefit 3]

**Watch the demo:**
[Video Link or GIF]

**Available for:**
- ✅ Pro users (unlimited access)
- ⚠️ Free users (limited to 20 messages/month)

[Upgrade to Pro]

We're constantly improving PrimeAI based on your feedback. Keep the suggestions coming!

Happy chatting!

The PrimeAI Team

---

**Footer:**
PrimeAI | primeai.app
[Unsubscribe] | [Privacy Policy]

---

## 8. Payment Failed Email

**Subject:** ⚠️ Payment issue with your PrimeAI subscription

**Preview Text:** Update your payment method to continue

**Body:**

---

Hi [First Name],

We tried to process your payment for PrimeAI Pro, but it didn't go through.

**What this means:**
- Your subscription is still active for now
- You have 7 days to update your payment method
- After 7 days, your account will revert to the free plan

**Update your payment method:**
[Update Payment Info]

**Common reasons for failed payments:**
- Expired credit card
- Insufficient funds
- Card declined by bank
- Billing address mismatch

**Need help?**
Reply to this email or contact our support team.

We don't want you to lose access to unlimited messages!

[Update Payment Now]

Thanks for being a valued PrimeAI Pro member.

Best regards,
The PrimeAI Team

---

**Footer:**
PrimeAI | primeai.app
[Privacy Policy]

---

## 9. Annual Subscription Renewal Reminder

**Subject:** Your PrimeAI annual subscription renews soon

**Preview Text:** Renewing on [Date] - $190/year

**Body:**

---

Hi [First Name],

Just a friendly reminder: Your PrimeAI annual subscription will automatically renew on [Renewal Date].

**Renewal details:**
- Plan: Annual Pro
- Amount: $190
- Payment method: [Card ending in XXXX]
- Next billing date: [Date]

**What you get:**
✅ Unlimited messages
✅ Priority support
✅ All premium features
✅ Early access to new features

**Need to make changes?**
- Update payment method: [Link]
- Switch to monthly: [Link]
- Cancel subscription: [Link]

**Want to continue?**
No action needed! Your subscription will renew automatically.

[Manage Subscription]

Thank you for being a loyal PrimeAI user!

Best regards,
The PrimeAI Team

P.S. Questions about your subscription? Just reply to this email.

---

**Footer:**
PrimeAI | primeai.app
[Unsubscribe] | [Privacy Policy]

---

## 10. Referral Program Email

**Subject:** Give $10, Get $10 🎁 Share PrimeAI with friends

**Preview Text:** Earn rewards for referrals

**Body:**

---

Hi [First Name],

Love PrimeAI? Share it with friends and earn rewards!

**How it works:**
1. Share your unique referral link
2. Friends get $10 off their first month
3. You get $10 credit when they subscribe

**Your referral link:**
[Unique Link]

**Easy sharing:**
[Share on Twitter] [Share on Facebook] [Share on LinkedIn] [Copy Link]

**No limit on rewards!**
Refer unlimited friends and stack your credits.

**Who should you refer?**
- Colleagues who need productivity tools
- Students working on projects
- Creators seeking inspiration
- Anyone who asks lots of questions

[Start Referring]

**Track your referrals:**
See how many friends have signed up in your dashboard.

[View Referral Dashboard]

Thanks for spreading the word about PrimeAI!

Best,
The PrimeAI Team

---

**Footer:**
PrimeAI | primeai.app
[Unsubscribe] | [Privacy Policy]

---

## Email Best Practices

### Timing
- Welcome: Immediately after signup
- Upgrade prompts: After 15 messages used
- Limit reached: Immediately when limit hit
- Reset notification: On reset day
- Churn prevention: Within 24 hours of cancellation
- Win-back: 30 days after cancellation
- Feature announcements: Mid-week, 10 AM user's timezone

### Personalization
- Always use first name
- Reference usage patterns
- Segment by plan type
- Customize based on behavior

### A/B Testing
- Test subject lines
- Test CTA buttons
- Test email length
- Test sending times

### Metrics to Track
- Open rate (target: 25%+)
- Click-through rate (target: 5%+)
- Conversion rate (target: 2%+)
- Unsubscribe rate (keep under 0.5%)

---

**Last Updated:** 2025
**Version:** 1.0