# PrimeAI Deployment Guide

Complete guide for deploying PrimeAI to production on Vercel.

## Prerequisites

- GitHub account
- Vercel account (sign up at [vercel.com](https://vercel.com))
- All services configured:
  - Neon PostgreSQL database
  - Clerk authentication
  - Stripe payments

## Quick Deploy (5 Minutes)

### 1. Push to GitHub

```bash
cd primeai
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/yourusername/primeai.git
git push -u origin main
```

### 2. Import to Vercel

1. Go to [vercel.com/new](https://vercel.com/new)
2. Click "Import Git Repository"
3. Select your GitHub repository
4. Click "Import"

### 3. Configure Environment Variables

In Vercel dashboard, add all environment variables from `.env`:

```env
# Database
DATABASE_URL=postgresql://user:password@host:5432/primeai?sslmode=require

# Clerk
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_live_xxxxx
CLERK_SECRET_KEY=sk_live_xxxxx
NEXT_PUBLIC_CLERK_SIGN_IN_URL=/sign-in
NEXT_PUBLIC_CLERK_SIGN_UP_URL=/sign-up
NEXT_PUBLIC_CLERK_AFTER_SIGN_IN_URL=/app
NEXT_PUBLIC_CLERK_AFTER_SIGN_UP_URL=/app

# Stripe
STRIPE_SECRET_KEY=sk_live_xxxxx
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_xxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxx
STRIPE_PRICE_ID_MONTHLY=price_xxxxx
STRIPE_PRICE_ID_ANNUAL=price_xxxxx

# App
NEXT_PUBLIC_APP_URL=https://your-domain.vercel.app
ADMIN_USER_IDS=user_xxxxx

# OpenAI (Optional)
OPENAI_API_KEY=sk-xxxxx
```

### 4. Deploy

1. Click "Deploy"
2. Wait for build to complete (2-3 minutes)
3. Your app is live! 🎉

## Detailed Setup

### Step 1: Prepare Production Database

#### Using Neon (Recommended)

1. Go to [neon.tech](https://neon.tech)
2. Create new project: "primeai-production"
3. Copy connection string
4. Add to Vercel environment variables

#### Run Migrations

```bash
# Set production DATABASE_URL
export DATABASE_URL="your-production-url"

# Run migrations
npx prisma migrate deploy

# Generate Prisma client
npx prisma generate
```

### Step 2: Configure Clerk for Production

1. Go to [clerk.com](https://clerk.com) dashboard
2. Select your application
3. Go to **Settings** → **Domains**
4. Add production domain: `your-domain.vercel.app`
5. Update redirect URLs:
   - Sign-in URL: `https://your-domain.vercel.app/sign-in`
   - Sign-up URL: `https://your-domain.vercel.app/sign-up`
   - After sign-in: `https://your-domain.vercel.app/app`
   - After sign-up: `https://your-domain.vercel.app/app`

6. Go to **API Keys**
7. Copy production keys (starts with `pk_live_` and `sk_live_`)
8. Add to Vercel environment variables

### Step 3: Configure Stripe for Production

1. Switch to **Live mode** in Stripe Dashboard
2. Complete account activation
3. Create live products (see STRIPE_SETUP_GUIDE.md)
4. Set up production webhook:
   - URL: `https://your-domain.vercel.app/api/webhooks/stripe`
   - Events: `checkout.session.completed`, `customer.subscription.updated`, `customer.subscription.deleted`
5. Copy live API keys and webhook secret
6. Add to Vercel environment variables

### Step 4: Custom Domain (Optional)

#### Add Custom Domain in Vercel

1. Go to project **Settings** → **Domains**
2. Add your domain: `primeai.app`
3. Follow DNS configuration instructions

#### Update DNS Records

Add these records to your domain provider:

**For apex domain (primeai.app):**
```
Type: A
Name: @
Value: 76.76.21.21
```

**For www subdomain:**
```
Type: CNAME
Name: www
Value: cname.vercel-dns.com
```

#### Update Environment Variables

After domain is verified:
```env
NEXT_PUBLIC_APP_URL=https://primeai.app
```

Update in:
- Vercel environment variables
- Clerk redirect URLs
- Stripe webhook URL

### Step 5: Configure Production Settings

#### Vercel Project Settings

1. **Build & Development Settings**
   - Build Command: `npm run build`
   - Output Directory: `.next`
   - Install Command: `npm install`

2. **Environment Variables**
   - Add all production variables
   - Mark sensitive variables as "Sensitive"

3. **Deployment Protection** (Optional)
   - Enable password protection for preview deployments
   - Useful for staging environment

#### Next.js Configuration

Update `next.config.js` for production:

```javascript
/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['img.clerk.com'],
  },
  experimental: {
    serverActions: {
      bodySizeLimit: '2mb',
    },
  },
  // Production optimizations
  swcMinify: true,
  compress: true,
  poweredByHeader: false,
}

module.exports = nextConfig
```

## Post-Deployment Checklist

### Functionality Testing

- [ ] **Homepage loads correctly**
  - Check hero section
  - Verify all links work
  - Test mobile responsiveness

- [ ] **Authentication works**
  - Sign up with email
  - Sign up with Google
  - Sign in with email
  - Sign in with Google
  - Sign out

- [ ] **Pricing page displays**
  - All plans visible
  - Prices correct
  - CTAs work

- [ ] **Chat interface works**
  - Can send messages
  - Receives responses
  - Message history saves
  - Usage counter updates

- [ ] **Subscription flow works**
  - Checkout opens
  - Payment processes
  - Webhook received
  - Database updates
  - User gets unlimited access

- [ ] **Settings page works**
  - Shows correct plan
  - Displays usage stats
  - Billing portal opens

- [ ] **Legal pages load**
  - Privacy policy
  - Terms of service
  - Refund policy

### SEO Verification

- [ ] **Sitemap accessible**
  - Visit: `https://your-domain.com/sitemap.xml`
  - Verify all pages listed

- [ ] **Robots.txt accessible**
  - Visit: `https://your-domain.com/robots.txt`
  - Verify correct rules

- [ ] **Meta tags present**
  - Check with [metatags.io](https://metatags.io)
  - Verify title, description, OG image

- [ ] **Submit to search engines**
  - Google Search Console
  - Bing Webmaster Tools

### Performance Testing

- [ ] **Lighthouse audit**
  - Performance: 90+
  - Accessibility: 90+
  - Best Practices: 90+
  - SEO: 90+

- [ ] **Page load times**
  - Homepage: <2s
  - App pages: <3s
  - API responses: <1s

### Security Verification

- [ ] **HTTPS enabled**
  - All pages use HTTPS
  - No mixed content warnings

- [ ] **Environment variables secure**
  - No secrets in client-side code
  - Sensitive variables marked

- [ ] **Authentication protected**
  - Protected routes require login
  - Middleware working correctly

- [ ] **Webhook signature verified**
  - Test webhook with real event
  - Verify signature validation

### Monitoring Setup

- [ ] **Vercel Analytics enabled**
  - Go to project → Analytics
  - Enable Web Analytics

- [ ] **Error tracking**
  - Set up Sentry (optional)
  - Monitor Vercel logs

- [ ] **Uptime monitoring**
  - Set up UptimeRobot (optional)
  - Monitor critical endpoints

## Continuous Deployment

### Automatic Deployments

Vercel automatically deploys when you push to GitHub:

```bash
# Make changes
git add .
git commit -m "Update feature"
git push

# Vercel automatically deploys
```

### Preview Deployments

Every pull request gets a preview deployment:

1. Create branch: `git checkout -b feature-name`
2. Make changes and commit
3. Push: `git push origin feature-name`
4. Create pull request on GitHub
5. Vercel creates preview deployment
6. Test preview before merging

### Production Deployments

Only `main` branch deploys to production:

1. Merge pull request to `main`
2. Vercel automatically deploys to production
3. Monitor deployment in Vercel dashboard

## Rollback Procedure

If deployment has issues:

### Quick Rollback

1. Go to Vercel dashboard
2. Click **Deployments**
3. Find last working deployment
4. Click **⋯** → **Promote to Production**

### Git Rollback

```bash
# Revert to previous commit
git revert HEAD
git push

# Or reset to specific commit
git reset --hard <commit-hash>
git push --force
```

## Environment Management

### Multiple Environments

Create separate projects for:
- **Development:** `primeai-dev`
- **Staging:** `primeai-staging`
- **Production:** `primeai`

Each with its own:
- Database
- Clerk application
- Stripe account (test/live)
- Environment variables

### Environment Variables by Stage

**Development:**
```env
NEXT_PUBLIC_APP_URL=http://localhost:3000
# Use test/development services
```

**Staging:**
```env
NEXT_PUBLIC_APP_URL=https://primeai-staging.vercel.app
# Use test services
```

**Production:**
```env
NEXT_PUBLIC_APP_URL=https://primeai.app
# Use live services
```

## Scaling Considerations

### Database Scaling

**Neon Auto-scaling:**
- Automatically scales compute
- Monitor usage in dashboard
- Upgrade plan if needed

**Connection Pooling:**
```typescript
// Use connection pooling for production
const db = new PrismaClient({
  datasources: {
    db: {
      url: process.env.DATABASE_URL,
    },
  },
})
```

### Vercel Scaling

**Automatic:**
- Vercel scales automatically
- No configuration needed
- Pay per usage

**Limits:**
- Free: 100GB bandwidth
- Pro: 1TB bandwidth
- Enterprise: Custom

### Caching Strategy

**Static Pages:**
```typescript
// Cache static pages
export const revalidate = 3600 // 1 hour
```

**API Routes:**
```typescript
// Cache API responses
export const revalidate = 60 // 1 minute
```

## Monitoring and Maintenance

### Daily Checks

- [ ] Check Vercel deployment status
- [ ] Monitor error logs
- [ ] Check Stripe dashboard for payments
- [ ] Review user signups

### Weekly Tasks

- [ ] Review analytics
- [ ] Check performance metrics
- [ ] Update dependencies
- [ ] Backup database

### Monthly Tasks

- [ ] Security audit
- [ ] Performance optimization
- [ ] Cost analysis
- [ ] Feature planning

## Troubleshooting

### Build Failures

**Check:**
1. Build logs in Vercel
2. TypeScript errors
3. Missing dependencies
4. Environment variables

**Fix:**
```bash
# Test build locally
npm run build

# Check for errors
npm run lint
```

### Runtime Errors

**Check:**
1. Vercel function logs
2. Browser console
3. Network requests
4. Database connection

**Debug:**
```typescript
// Add logging
console.log('Debug info:', data)

// Check in Vercel logs
```

### Database Connection Issues

**Check:**
1. DATABASE_URL correct
2. Database accessible
3. Connection pool limits
4. Prisma client generated

**Fix:**
```bash
# Regenerate Prisma client
npx prisma generate

# Test connection
npx prisma db push
```

### Webhook Issues

**Check:**
1. Webhook URL accessible
2. Signature verification
3. Event handling
4. Database updates

**Debug:**
```bash
# Test webhook locally
stripe trigger checkout.session.completed

# Check Stripe logs
# Check Vercel function logs
```

## Cost Optimization

### Vercel Costs

**Free Tier:**
- 100GB bandwidth
- Unlimited deployments
- Good for starting out

**Pro Tier ($20/month):**
- 1TB bandwidth
- Better performance
- Team features

### Database Costs

**Neon Free:**
- 0.5GB storage
- Good for testing

**Neon Pro ($19/month):**
- 10GB storage
- Better performance
- Auto-scaling

### Stripe Costs

- 2.9% + $0.30 per transaction
- No monthly fees
- Volume discounts available

## Security Best Practices

### Regular Updates

```bash
# Update dependencies monthly
npm update

# Check for vulnerabilities
npm audit

# Fix vulnerabilities
npm audit fix
```

### Environment Security

- [ ] Rotate API keys quarterly
- [ ] Use strong passwords
- [ ] Enable 2FA on all services
- [ ] Limit admin access
- [ ] Monitor access logs

### Data Protection

- [ ] Regular database backups
- [ ] Encrypt sensitive data
- [ ] GDPR compliance
- [ ] Privacy policy updated
- [ ] Terms of service current

## Support Resources

- **Vercel Docs:** [vercel.com/docs](https://vercel.com/docs)
- **Next.js Docs:** [nextjs.org/docs](https://nextjs.org/docs)
- **Vercel Support:** [vercel.com/support](https://vercel.com/support)
- **Community:** [github.com/vercel/next.js/discussions](https://github.com/vercel/next.js/discussions)

## Success Metrics

Track these KPIs:

- **Uptime:** 99.9%+
- **Response time:** <2s
- **Error rate:** <1%
- **Conversion rate:** Track signups → paid
- **Churn rate:** Monitor cancellations

---

**Deployment Complete! 🚀**

Your PrimeAI application is now live and ready to serve users.

**Next Steps:**
1. Monitor initial traffic
2. Gather user feedback
3. Plan feature updates
4. Scale as needed

**Need Help?**
- Check Vercel logs
- Review this guide
- Contact Vercel support
- Join Next.js community

**Last Updated:** 2025