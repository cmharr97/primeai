import { db } from './db'
import { getCurrentMonth } from './utils'

export const FREE_MESSAGE_LIMIT = 20

export async function checkMessageLimit(userId: string): Promise<{
  allowed: boolean
  remaining: number
  limit: number
  isPaid: boolean
}> {
  const user = await db.user.findUnique({
    where: { id: userId },
    include: { subscription: true },
  })

  if (!user) {
    throw new Error('User not found')
  }

  const isPaid = user.subscription?.status === 'active'

  if (isPaid) {
    return {
      allowed: true,
      remaining: -1, // unlimited
      limit: -1,
      isPaid: true,
    }
  }

  const currentMonth = getCurrentMonth()
  const usage = await db.usage.findUnique({
    where: {
      userId_month: {
        userId,
        month: currentMonth,
      },
    },
  })

  const count = usage?.count || 0
  const remaining = Math.max(0, FREE_MESSAGE_LIMIT - count)

  return {
    allowed: count < FREE_MESSAGE_LIMIT,
    remaining,
    limit: FREE_MESSAGE_LIMIT,
    isPaid: false,
  }
}

export async function incrementUsage(userId: string): Promise<void> {
  const currentMonth = getCurrentMonth()

  await db.usage.upsert({
    where: {
      userId_month: {
        userId,
        month: currentMonth,
      },
    },
    update: {
      count: {
        increment: 1,
      },
    },
    create: {
      userId,
      month: currentMonth,
      count: 1,
    },
  })
}

export async function getOrCreateUser(clerkId: string, email: string, name?: string, imageUrl?: string) {
  let user = await db.user.findUnique({
    where: { clerkId },
    include: { subscription: true },
  })

  if (!user) {
    user = await db.user.create({
      data: {
        clerkId,
        email,
        name,
        imageUrl,
        subscription: {
          create: {
            stripeCustomerId: '', // Will be set when user subscribes
            status: 'free',
            plan: 'free',
          },
        },
      },
      include: { subscription: true },
    })
  }

  return user
}