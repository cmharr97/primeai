import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"
import { Zap, Shield, Sparkles, MessageSquare, TrendingUp, Users } from "lucide-react"

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col bg-[#0F1115]">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative py-20 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-[#00D8FF]/10 to-[#00FF95]/10 blur-3xl" />
        <div className="relative max-w-7xl mx-auto text-center">
          <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fade-in">
            <span className="gradient-text">PrimeAI</span>
            <br />
            <span className="text-white">The Sharpest AI Assistant</span>
          </h1>
          <p className="text-xl text-gray-300 mb-8 max-w-2xl mx-auto animate-slide-up">
            Experience the future of AI assistance. Get instant answers, creative solutions, 
            and intelligent conversations powered by cutting-edge technology.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center animate-slide-up">
            <Link href="/app">
              <Button size="lg" variant="gradient" className="text-lg px-8">
                Start Free Trial
              </Button>
            </Link>
            <Link href="/pricing">
              <Button size="lg" variant="outline" className="text-lg px-8 border-[#00D8FF] text-[#00D8FF] hover:bg-[#00D8FF]/10">
                View Pricing
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-black/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Why Choose <span className="gradient-text">PrimeAI</span>?
            </h2>
            <p className="text-xl text-gray-400">
              Powerful features designed for the modern user
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="bg-gray-900/50 border-gray-800 hover:border-[#00D8FF]/50 transition-all hover:glow-effect">
              <CardHeader>
                <Zap className="w-12 h-12 text-[#00D8FF] mb-4" />
                <CardTitle className="text-white">Lightning Fast</CardTitle>
                <CardDescription>
                  Get instant responses powered by state-of-the-art AI technology
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-gray-900/50 border-gray-800 hover:border-[#00FF95]/50 transition-all hover:glow-effect-green">
              <CardHeader>
                <Shield className="w-12 h-12 text-[#00FF95] mb-4" />
                <CardTitle className="text-white">Secure & Private</CardTitle>
                <CardDescription>
                  Your conversations are encrypted and never shared with third parties
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-gray-900/50 border-gray-800 hover:border-[#00D8FF]/50 transition-all hover:glow-effect">
              <CardHeader>
                <Sparkles className="w-12 h-12 text-[#00D8FF] mb-4" />
                <CardTitle className="text-white">Smart & Intuitive</CardTitle>
                <CardDescription>
                  Advanced AI that understands context and delivers relevant answers
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-gray-900/50 border-gray-800 hover:border-[#00FF95]/50 transition-all hover:glow-effect-green">
              <CardHeader>
                <MessageSquare className="w-12 h-12 text-[#00FF95] mb-4" />
                <CardTitle className="text-white">Natural Conversations</CardTitle>
                <CardDescription>
                  Chat naturally like you would with a human assistant
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-gray-900/50 border-gray-800 hover:border-[#00D8FF]/50 transition-all hover:glow-effect">
              <CardHeader>
                <TrendingUp className="w-12 h-12 text-[#00D8FF] mb-4" />
                <CardTitle className="text-white">Always Improving</CardTitle>
                <CardDescription>
                  Regular updates with new features and enhanced capabilities
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-gray-900/50 border-gray-800 hover:border-[#00FF95]/50 transition-all hover:glow-effect-green">
              <CardHeader>
                <Users className="w-12 h-12 text-[#00FF95] mb-4" />
                <CardTitle className="text-white">Trusted by Thousands</CardTitle>
                <CardDescription>
                  Join our growing community of satisfied users worldwide
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              What Our Users Say
            </h2>
            <p className="text-xl text-gray-400">
              Real feedback from real users
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardDescription className="text-gray-300 text-base">
                  "PrimeAI has completely transformed how I work. The responses are incredibly accurate and helpful. Best AI assistant I've used!"
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="font-semibold text-white">Sarah Johnson</p>
                <p className="text-sm text-gray-400">Product Manager</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardDescription className="text-gray-300 text-base">
                  "The speed and quality of responses are unmatched. PrimeAI understands context better than any other AI tool I've tried."
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="font-semibold text-white">Michael Chen</p>
                <p className="text-sm text-gray-400">Software Developer</p>
              </CardContent>
            </Card>

            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardDescription className="text-gray-300 text-base">
                  "Simple, powerful, and reliable. PrimeAI has become an essential part of my daily workflow. Highly recommended!"
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="font-semibold text-white">Emily Rodriguez</p>
                <p className="text-sm text-gray-400">Content Creator</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-black/30">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-white mb-4">
              Frequently Asked Questions
            </h2>
          </div>

          <div className="space-y-6">
            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">What is PrimeAI?</CardTitle>
                <CardDescription className="text-gray-300 text-base">
                  PrimeAI is an advanced AI assistant that helps you with tasks, answers questions, 
                  and provides intelligent solutions using cutting-edge artificial intelligence technology.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">How does the free trial work?</CardTitle>
                <CardDescription className="text-gray-300 text-base">
                  You get 20 free messages per month to try PrimeAI. No credit card required. 
                  Upgrade anytime for unlimited access.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Can I cancel my subscription?</CardTitle>
                <CardDescription className="text-gray-300 text-base">
                  Yes, you can cancel your subscription at any time. You'll continue to have access 
                  until the end of your billing period.
                </CardDescription>
              </CardHeader>
            </Card>

            <Card className="bg-gray-900/50 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Is my data secure?</CardTitle>
                <CardDescription className="text-gray-300 text-base">
                  Absolutely. We use industry-standard encryption and never share your data with third parties. 
                  Your privacy is our top priority.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Ready to Experience <span className="gradient-text">PrimeAI</span>?
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Join thousands of users who are already using PrimeAI to boost their productivity
          </p>
          <Link href="/app">
            <Button size="lg" variant="gradient" className="text-lg px-12">
              Get Started Free
            </Button>
          </Link>
        </div>
      </section>

      <Footer />
    </div>
  )
}