import { Navbar } from "@/components/navbar"
import { Footer } from "@/components/footer"

export default function RefundPage() {
  return (
    <div className="min-h-screen flex flex-col bg-[#0F1115]">
      <Navbar />
      
      <div className="flex-1 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <h1 className="text-4xl font-bold text-white mb-8">Refund Policy</h1>
        
        <div className="prose prose-invert max-w-none space-y-6 text-gray-300">
          <p className="text-lg">
            Last updated: {new Date().toLocaleDateString()}
          </p>

          <section>
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">1. 30-Day Money-Back Guarantee</h2>
            <p>
              We stand behind the quality of PrimeAI. If you're not completely satisfied with your subscription, 
              we offer a 30-day money-back guarantee from the date of your initial purchase.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">2. Eligibility for Refunds</h2>
            <p>
              To be eligible for a refund, you must meet the following criteria:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Request must be made within 30 days of your initial subscription purchase</li>
              <li>This is your first subscription to PrimeAI (not applicable to renewals)</li>
              <li>You have not previously received a refund from PrimeAI</li>
              <li>Your account has not been terminated for violation of our Terms of Service</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">3. How to Request a Refund</h2>
            <p>
              To request a refund, please follow these steps:
            </p>
            <ol className="list-decimal pl-6 space-y-2">
              <li>Contact our support team at <span className="text-[#00D8FF]">support@primeai.app</span></li>
              <li>Include your account email and reason for the refund request</li>
              <li>Our team will review your request within 2-3 business days</li>
              <li>If approved, your refund will be processed within 5-10 business days</li>
            </ol>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">4. Refund Processing</h2>
            <p>
              Once your refund is approved:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>The refund will be issued to your original payment method</li>
              <li>Processing time depends on your payment provider (typically 5-10 business days)</li>
              <li>You will receive a confirmation email once the refund is processed</li>
              <li>Your subscription will be immediately canceled</li>
              <li>You will lose access to premium features</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">5. Subscription Renewals</h2>
            <p>
              Please note that:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Subscription renewals are not eligible for refunds</li>
              <li>You can cancel your subscription at any time to prevent future charges</li>
              <li>Cancellation takes effect at the end of your current billing period</li>
              <li>You will retain access to premium features until the end of the paid period</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">6. Annual Subscriptions</h2>
            <p>
              For annual subscriptions:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>The 30-day money-back guarantee applies to the full annual amount</li>
              <li>After 30 days, annual subscriptions are non-refundable</li>
              <li>You may cancel to prevent the next year's renewal</li>
              <li>Partial refunds for unused months are not provided</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">7. Exceptions</h2>
            <p>
              Refunds will not be provided in the following cases:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Account termination due to Terms of Service violations</li>
              <li>Abuse of the refund policy</li>
              <li>Requests made after the 30-day guarantee period</li>
              <li>Subscription renewals (only initial purchases are eligible)</li>
              <li>Free trial conversions (if you used a free trial before subscribing)</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">8. Cancellation vs. Refund</h2>
            <p>
              Understanding the difference:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Cancellation:</strong> Stops future billing but you keep access until period ends</li>
              <li><strong>Refund:</strong> Returns your money and immediately ends your subscription</li>
              <li>You can cancel anytime through your account settings or billing portal</li>
              <li>Refunds require contacting support and meeting eligibility criteria</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">9. Promotional Offers</h2>
            <p>
              For subscriptions purchased with promotional discounts or special offers:
            </p>
            <ul className="list-disc pl-6 space-y-2">
              <li>The 30-day guarantee still applies</li>
              <li>Refund will be for the amount actually paid</li>
              <li>Promotional credits or discounts cannot be refunded separately</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-white mt-8 mb-4">10. Contact Us</h2>
            <p>
              If you have any questions about our refund policy or need assistance with a refund request, 
              please contact us at:
            </p>
            <p className="text-[#00D8FF]">support@primeai.app</p>
            <p className="mt-4">
              We're committed to your satisfaction and will work with you to resolve any concerns you may have.
            </p>
          </section>
        </div>
      </div>

      <Footer />
    </div>
  )
}