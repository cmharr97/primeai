import { NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs'
import { db } from '@/lib/db'
import { getOrCreateUser, checkMessageLimit } from '@/lib/subscription'

export async function GET(req: Request) {
  try {
    const { userId } = auth()
    
    if (!userId) {
      return new NextResponse('Unauthorized', { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const userEmail = searchParams.get('email') || ''
    const userName = searchParams.get('name') || ''

    // Get or create user
    const user = await getOrCreateUser(userId, userEmail, userName)

    // Get subscription
    const subscription = await db.subscription.findUnique({
      where: { userId: user.id },
    })

    // Get usage info
    const limitInfo = await checkMessageLimit(user.id)

    return NextResponse.json({
      subscription,
      usage: limitInfo,
    })
  } catch (error) {
    console.error('[SUBSCRIPTION_ERROR]', error)
    return new NextResponse('Internal Error', { status: 500 })
  }
}