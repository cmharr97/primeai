import { NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs'
import { db } from '@/lib/db'
import { checkMessageLimit, incrementUsage, getOrCreateUser } from '@/lib/subscription'

// Mock AI response - Replace with actual OpenAI integration
async function generateAIResponse(message: string): Promise<string> {
  // Simulate AI processing delay
  await new Promise(resolve => setTimeout(resolve, 1000))
  
  // Mock responses based on keywords
  if (message.toLowerCase().includes('hello') || message.toLowerCase().includes('hi')) {
    return "Hello! I'm PrimeAI, your intelligent assistant. How can I help you today?"
  }
  
  if (message.toLowerCase().includes('help')) {
    return "I'm here to help! You can ask me questions, get creative ideas, solve problems, or just have a conversation. What would you like to know?"
  }
  
  if (message.toLowerCase().includes('pricing') || message.toLowerCase().includes('cost')) {
    return "PrimeAI offers flexible pricing: Free tier with 20 messages/month, Monthly plan at $19/month for unlimited messages, and Annual plan at $190/year (save $38). Visit our pricing page for more details!"
  }
  
  // Default response
  return `I understand you're asking about "${message}". As an AI assistant, I can help you with a wide range of tasks including answering questions, providing information, creative writing, problem-solving, and more. This is a demo response - in production, this would be powered by advanced AI models.`
}

export async function POST(req: Request) {
  try {
    const { userId } = auth()
    
    if (!userId) {
      return new NextResponse('Unauthorized', { status: 401 })
    }

    const { message, userEmail, userName } = await req.json()

    if (!message) {
      return new NextResponse('Message is required', { status: 400 })
    }

    // Get or create user
    const user = await getOrCreateUser(userId, userEmail, userName)

    // Check message limit
    const limitCheck = await checkMessageLimit(user.id)

    if (!limitCheck.allowed) {
      return NextResponse.json({
        error: 'Message limit reached',
        limit: limitCheck.limit,
        remaining: limitCheck.remaining,
        isPaid: limitCheck.isPaid,
      }, { status: 429 })
    }

    // Save user message
    await db.message.create({
      data: {
        userId: user.id,
        role: 'user',
        content: message,
      },
    })

    // Generate AI response
    const aiResponse = await generateAIResponse(message)

    // Save AI response
    await db.message.create({
      data: {
        userId: user.id,
        role: 'assistant',
        content: aiResponse,
      },
    })

    // Increment usage
    await incrementUsage(user.id)

    // Get updated limit info
    const updatedLimit = await checkMessageLimit(user.id)

    return NextResponse.json({
      response: aiResponse,
      remaining: updatedLimit.remaining,
      limit: updatedLimit.limit,
      isPaid: updatedLimit.isPaid,
    })
  } catch (error) {
    console.error('[CHAT_ERROR]', error)
    return new NextResponse('Internal Error', { status: 500 })
  }
}