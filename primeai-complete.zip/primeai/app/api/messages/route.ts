import { NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs'
import { db } from '@/lib/db'
import { getOrCreateUser } from '@/lib/subscription'

export async function GET(req: Request) {
  try {
    const { userId } = auth()
    
    if (!userId) {
      return new NextResponse('Unauthorized', { status: 401 })
    }

    const { searchParams } = new URL(req.url)
    const userEmail = searchParams.get('email') || ''
    const userName = searchParams.get('name') || ''

    // Get or create user
    const user = await getOrCreateUser(userId, userEmail, userName)

    // Get messages
    const messages = await db.message.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'asc' },
      take: 100, // Limit to last 100 messages
    })

    return NextResponse.json(messages)
  } catch (error) {
    console.error('[MESSAGES_ERROR]', error)
    return new NextResponse('Internal Error', { status: 500 })
  }
}