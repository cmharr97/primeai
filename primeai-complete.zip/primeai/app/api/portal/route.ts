import { NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs'
import { db } from '@/lib/db'
import { createBillingPortalSession } from '@/lib/stripe'
import { getOrCreateUser } from '@/lib/subscription'

export async function POST(req: Request) {
  try {
    const { userId } = auth()
    
    if (!userId) {
      return new NextResponse('Unauthorized', { status: 401 })
    }

    const { userEmail, userName } = await req.json()

    // Get or create user
    const user = await getOrCreateUser(userId, userEmail, userName)

    // Get subscription
    const subscription = await db.subscription.findUnique({
      where: { userId: user.id },
    })

    if (!subscription?.stripeCustomerId) {
      return new NextResponse('No subscription found', { status: 404 })
    }

    // Create portal session
    const session = await createBillingPortalSession(subscription.stripeCustomerId)

    return NextResponse.json({ url: session.url })
  } catch (error) {
    console.error('[PORTAL_ERROR]', error)
    return new NextResponse('Internal Error', { status: 500 })
  }
}