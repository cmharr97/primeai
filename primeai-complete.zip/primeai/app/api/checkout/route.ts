import { NextResponse } from 'next/server'
import { auth } from '@clerk/nextjs'
import { db } from '@/lib/db'
import { createCheckoutSession, createStripeCustomer, getStripeCustomerByEmail } from '@/lib/stripe'
import { getOrCreateUser } from '@/lib/subscription'

export async function POST(req: Request) {
  try {
    const { userId } = auth()
    
    if (!userId) {
      return new NextResponse('Unauthorized', { status: 401 })
    }

    const { priceId, userEmail, userName } = await req.json()

    if (!priceId) {
      return new NextResponse('Price ID is required', { status: 400 })
    }

    // Get or create user
    const user = await getOrCreateUser(userId, userEmail, userName)

    // Get or create Stripe customer
    let customer = await getStripeCustomerByEmail(user.email)
    
    if (!customer) {
      customer = await createStripeCustomer(user.email, user.name || undefined)
      
      // Update subscription with customer ID
      await db.subscription.update({
        where: { userId: user.id },
        data: { stripeCustomerId: customer.id },
      })
    }

    // Create checkout session
    const session = await createCheckoutSession(customer.id, priceId, user.id)

    return NextResponse.json({ url: session.url })
  } catch (error) {
    console.error('[CHECKOUT_ERROR]', error)
    return new NextResponse('Internal Error', { status: 500 })
  }
}