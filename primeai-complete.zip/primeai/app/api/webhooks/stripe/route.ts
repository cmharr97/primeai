import { headers } from 'next/headers'
import { NextResponse } from 'next/server'
import Stripe from 'stripe'
import { db } from '@/lib/db'
import { stripe } from '@/lib/stripe'

export async function POST(req: Request) {
  const body = await req.text()
  const signature = headers().get('Stripe-Signature') as string

  let event: Stripe.Event

  try {
    event = stripe.webhooks.constructEvent(
      body,
      signature,
      process.env.STRIPE_WEBHOOK_SECRET!
    )
  } catch (error: any) {
    return new NextResponse(`Webhook Error: ${error.message}`, { status: 400 })
  }

  const session = event.data.object as Stripe.Checkout.Session
  const subscription = event.data.object as Stripe.Subscription

  try {
    switch (event.type) {
      case 'checkout.session.completed':
        // Handle successful checkout
        if (session.mode === 'subscription') {
          const subscriptionId = session.subscription as string
          const customerId = session.customer as string
          const userId = session.metadata?.userId

          if (userId) {
            await db.subscription.update({
              where: { userId },
              data: {
                stripeSubscriptionId: subscriptionId,
                stripeCustomerId: customerId,
                stripePriceId: session.line_items?.data[0]?.price?.id,
                status: 'active',
                plan: session.line_items?.data[0]?.price?.id === process.env.STRIPE_PRICE_ID_ANNUAL ? 'annual' : 'monthly',
                stripeCurrentPeriodEnd: new Date(
                  (session as any).current_period_end * 1000
                ),
              },
            })
          }
        }
        break

      case 'customer.subscription.updated':
        // Handle subscription updates
        await db.subscription.update({
          where: { stripeSubscriptionId: subscription.id },
          data: {
            status: subscription.status === 'active' ? 'active' : subscription.status === 'canceled' ? 'canceled' : 'expired',
            stripePriceId: subscription.items.data[0].price.id,
            stripeCurrentPeriodEnd: new Date(subscription.current_period_end * 1000),
          },
        })
        break

      case 'customer.subscription.deleted':
        // Handle subscription cancellation
        await db.subscription.update({
          where: { stripeSubscriptionId: subscription.id },
          data: {
            status: 'canceled',
            stripeCurrentPeriodEnd: new Date(subscription.current_period_end * 1000),
          },
        })
        break

      default:
        console.log(`Unhandled event type: ${event.type}`)
    }

    return new NextResponse(null, { status: 200 })
  } catch (error) {
    console.error('Error processing webhook:', error)
    return new NextResponse('Webhook handler failed', { status: 500 })
  }
}