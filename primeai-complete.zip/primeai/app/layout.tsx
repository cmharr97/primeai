import type { Metadata } from "next";
import { Inter } from "next/font/google";
import { ClerkProvider } from "@clerk/nextjs";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "PrimeAI - The Sharpest AI Assistant on the Web",
  description: "Experience the future of AI assistance with PrimeAI. Get instant answers, creative solutions, and intelligent conversations.",
  keywords: ["AI", "assistant", "chatbot", "artificial intelligence", "PrimeAI"],
  authors: [{ name: "PrimeAI Team" }],
  openGraph: {
    title: "PrimeAI - The Sharpest AI Assistant on the Web",
    description: "Experience the future of AI assistance with PrimeAI.",
    url: "https://primeai.app",
    siteName: "PrimeAI",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
      },
    ],
    locale: "en_US",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "PrimeAI - The Sharpest AI Assistant on the Web",
    description: "Experience the future of AI assistance with PrimeAI.",
    images: ["/og-image.png"],
  },
  robots: {
    index: true,
    follow: true,
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <ClerkProvider>
      <html lang="en" className="dark">
        <body className={inter.className}>
          {children}
          <Toaster />
        </body>
      </html>
    </ClerkProvider>
  );
}