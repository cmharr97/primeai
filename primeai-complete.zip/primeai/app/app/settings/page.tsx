"use client"

import { useEffect, useState } from "react"
import { useUser } from "@clerk/nextjs"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { Loader2, CreditCard, User, Mail } from "lucide-react"

interface SubscriptionInfo {
  subscription: {
    status: string
    plan: string
    stripeCurrentPeriodEnd: string | null
  }
  usage: {
    remaining: number
    limit: number
    isPaid: boolean
  }
}

export default function SettingsPage() {
  const { user } = useUser()
  const { toast } = useToast()
  const [subscriptionInfo, setSubscriptionInfo] = useState<SubscriptionInfo | null>(null)
  const [loading, setLoading] = useState(true)
  const [portalLoading, setPortalLoading] = useState(false)

  useEffect(() => {
    if (user) {
      loadSubscription()
    }
  }, [user])

  const loadSubscription = async () => {
    try {
      const response = await fetch(`/api/subscription?email=${user?.emailAddresses[0]?.emailAddress}&name=${user?.fullName}`)
      if (response.ok) {
        const data = await response.json()
        setSubscriptionInfo(data)
      }
    } catch (error) {
      console.error('Error loading subscription:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleManageBilling = async () => {
    setPortalLoading(true)
    try {
      const response = await fetch('/api/portal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userEmail: user?.emailAddresses[0]?.emailAddress,
          userName: user?.fullName,
        }),
      })

      const data = await response.json()
      if (data.url) {
        window.location.href = data.url
      }
    } catch (error) {
      console.error('Error opening portal:', error)
      toast({
        title: "Error",
        description: "Failed to open billing portal. Please try again.",
        variant: "destructive",
      })
    } finally {
      setPortalLoading(false)
    }
  }

  const handleUpgrade = async () => {
    try {
      const response = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          priceId: process.env.NEXT_PUBLIC_STRIPE_PRICE_ID_MONTHLY,
          userEmail: user?.emailAddresses[0]?.emailAddress,
          userName: user?.fullName,
        }),
      })

      const data = await response.json()
      if (data.url) {
        window.location.href = data.url
      }
    } catch (error) {
      console.error('Error creating checkout:', error)
      toast({
        title: "Error",
        description: "Failed to start checkout. Please try again.",
        variant: "destructive",
      })
    }
  }

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-center h-64">
          <Loader2 className="w-8 h-8 animate-spin text-[#00D8FF]" />
        </div>
      </div>
    )
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-white mb-8">Settings</h1>

      <div className="space-y-6">
        {/* Account Information */}
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <User className="w-5 h-5 text-[#00D8FF]" />
              Account Information
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm text-gray-400">Name</label>
              <p className="text-white">{user?.fullName || 'Not set'}</p>
            </div>
            <div>
              <label className="text-sm text-gray-400">Email</label>
              <p className="text-white">{user?.emailAddresses[0]?.emailAddress}</p>
            </div>
          </CardContent>
        </Card>

        {/* Subscription */}
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-[#00FF95]" />
              Subscription
            </CardTitle>
            <CardDescription>
              Manage your subscription and billing
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm text-gray-400">Current Plan</label>
              <p className="text-white text-lg font-semibold capitalize">
                {subscriptionInfo?.subscription.plan || 'Free'}
              </p>
            </div>

            {subscriptionInfo?.usage.isPaid ? (
              <>
                <div>
                  <label className="text-sm text-gray-400">Status</label>
                  <p className="text-[#00FF95] font-semibold capitalize">
                    {subscriptionInfo.subscription.status}
                  </p>
                </div>
                {subscriptionInfo.subscription.stripeCurrentPeriodEnd && (
                  <div>
                    <label className="text-sm text-gray-400">Next Billing Date</label>
                    <p className="text-white">
                      {new Date(subscriptionInfo.subscription.stripeCurrentPeriodEnd).toLocaleDateString()}
                    </p>
                  </div>
                )}
                <Button
                  onClick={handleManageBilling}
                  disabled={portalLoading}
                  variant="outline"
                  className="border-gray-700"
                >
                  {portalLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Loading...
                    </>
                  ) : (
                    'Manage Billing'
                  )}
                </Button>
              </>
            ) : (
              <>
                <div>
                  <label className="text-sm text-gray-400">Messages Used</label>
                  <p className="text-white">
                    {(subscriptionInfo?.usage.limit || 20) - (subscriptionInfo?.usage.remaining || 0)} / {subscriptionInfo?.usage.limit || 20}
                  </p>
                </div>
                <Button
                  onClick={handleUpgrade}
                  variant="gradient"
                >
                  Upgrade to Pro
                </Button>
              </>
            )}
          </CardContent>
        </Card>

        {/* Usage Statistics */}
        <Card className="bg-gray-900/50 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Usage Statistics</CardTitle>
            <CardDescription>
              Your current usage this month
            </CardDescription>
          </CardHeader>
          <CardContent>
            {subscriptionInfo?.usage.isPaid ? (
              <div className="text-center py-8">
                <p className="text-4xl font-bold gradient-text mb-2">∞</p>
                <p className="text-gray-400">Unlimited messages</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-400">Messages Remaining</span>
                  <span className="text-white font-semibold">
                    {subscriptionInfo?.usage.remaining || 0}
                  </span>
                </div>
                <div className="w-full bg-gray-800 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-[#00D8FF] to-[#00FF95] h-2 rounded-full transition-all"
                    style={{
                      width: `${((subscriptionInfo?.usage.remaining || 0) / (subscriptionInfo?.usage.limit || 20)) * 100}%`
                    }}
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}