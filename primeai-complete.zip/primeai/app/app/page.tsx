"use client"

import { useEffect, useState, useRef } from "react"
import { useUser } from "@clerk/nextjs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useToast } from "@/components/ui/use-toast"
import { Send, Loader2, Copy, Share2, Sparkles } from "lucide-react"
import Link from "next/link"

interface Message {
  id: string
  role: string
  content: string
  createdAt: string
}

interface SubscriptionInfo {
  subscription: {
    status: string
    plan: string
  }
  usage: {
    remaining: number
    limit: number
    isPaid: boolean
  }
}

export default function AppPage() {
  const { user } = useUser()
  const { toast } = useToast()
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [loading, setLoading] = useState(false)
  const [subscriptionInfo, setSubscriptionInfo] = useState<SubscriptionInfo | null>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  useEffect(() => {
    if (user) {
      loadMessages()
      loadSubscription()
    }
  }, [user])

  const loadMessages = async () => {
    try {
      const response = await fetch(`/api/messages?email=${user?.emailAddresses[0]?.emailAddress}&name=${user?.fullName}`)
      if (response.ok) {
        const data = await response.json()
        setMessages(data)
      }
    } catch (error) {
      console.error('Error loading messages:', error)
    }
  }

  const loadSubscription = async () => {
    try {
      const response = await fetch(`/api/subscription?email=${user?.emailAddresses[0]?.emailAddress}&name=${user?.fullName}`)
      if (response.ok) {
        const data = await response.json()
        setSubscriptionInfo(data)
      }
    } catch (error) {
      console.error('Error loading subscription:', error)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!input.trim() || loading) return

    const userMessage = input.trim()
    setInput("")
    setLoading(true)

    // Add user message optimistically
    const tempUserMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: userMessage,
      createdAt: new Date().toISOString(),
    }
    setMessages(prev => [...prev, tempUserMessage])

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: userMessage,
          userEmail: user?.emailAddresses[0]?.emailAddress,
          userName: user?.fullName,
        }),
      })

      const data = await response.json()

      if (response.status === 429) {
        toast({
          title: "Message Limit Reached",
          description: `You've used all ${data.limit} free messages this month. Upgrade to continue!`,
          variant: "destructive",
        })
        // Remove optimistic message
        setMessages(prev => prev.filter(m => m.id !== tempUserMessage.id))
        return
      }

      if (!response.ok) {
        throw new Error('Failed to send message')
      }

      // Add AI response
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.response,
        createdAt: new Date().toISOString(),
      }
      setMessages(prev => [...prev, aiMessage])

      // Update subscription info
      if (subscriptionInfo) {
        setSubscriptionInfo({
          ...subscriptionInfo,
          usage: {
            ...subscriptionInfo.usage,
            remaining: data.remaining,
          },
        })
      }
    } catch (error) {
      console.error('Error sending message:', error)
      toast({
        title: "Error",
        description: "Failed to send message. Please try again.",
        variant: "destructive",
      })
      // Remove optimistic message
      setMessages(prev => prev.filter(m => m.id !== tempUserMessage.id))
    } finally {
      setLoading(false)
    }
  }

  const copyMessage = (content: string) => {
    navigator.clipboard.writeText(content)
    toast({
      title: "Copied!",
      description: "Message copied to clipboard",
    })
  }

  const handleUpgrade = async () => {
    try {
      const response = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          priceId: process.env.NEXT_PUBLIC_STRIPE_PRICE_ID_MONTHLY,
          userEmail: user?.emailAddresses[0]?.emailAddress,
          userName: user?.fullName,
        }),
      })

      const data = await response.json()
      if (data.url) {
        window.location.href = data.url
      }
    } catch (error) {
      console.error('Error creating checkout:', error)
      toast({
        title: "Error",
        description: "Failed to start checkout. Please try again.",
        variant: "destructive",
      })
    }
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Sidebar */}
        <div className="lg:col-span-1 space-y-4">
          <Card className="bg-gray-900/50 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-[#00D8FF]" />
                Usage
              </CardTitle>
            </CardHeader>
            <CardContent>
              {subscriptionInfo?.usage.isPaid ? (
                <div className="space-y-2">
                  <p className="text-2xl font-bold gradient-text">Unlimited</p>
                  <p className="text-sm text-gray-400">
                    {subscriptionInfo.subscription.plan === 'annual' ? 'Annual' : 'Monthly'} Plan
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-2xl font-bold text-white">
                    {subscriptionInfo?.usage.remaining || 0} / {subscriptionInfo?.usage.limit || 20}
                  </p>
                  <p className="text-sm text-gray-400">Messages remaining</p>
                  <Button 
                    variant="gradient" 
                    className="w-full mt-4"
                    onClick={handleUpgrade}
                  >
                    Upgrade to Pro
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>

          <Card className="bg-gray-900/50 border-gray-800">
            <CardHeader>
              <CardTitle className="text-white text-sm">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Link href="/pricing">
                <Button variant="outline" className="w-full justify-start border-gray-700">
                  View Pricing
                </Button>
              </Link>
              <Link href="/app/settings">
                <Button variant="outline" className="w-full justify-start border-gray-700">
                  Settings
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>

        {/* Chat Area */}
        <div className="lg:col-span-3">
          <Card className="bg-gray-900/50 border-gray-800 h-[calc(100vh-12rem)]">
            <CardHeader className="border-b border-gray-800">
              <CardTitle className="text-white flex items-center gap-2">
                <div className="w-3 h-3 bg-[#00FF95] rounded-full animate-pulse" />
                Chat with PrimeAI
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0 flex flex-col h-[calc(100%-5rem)]">
              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-6 space-y-4">
                {messages.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-center">
                    <Sparkles className="w-16 h-16 text-[#00D8FF] mb-4" />
                    <h3 className="text-2xl font-bold text-white mb-2">
                      Welcome to PrimeAI
                    </h3>
                    <p className="text-gray-400 max-w-md">
                      Start a conversation by typing a message below. I'm here to help with anything you need!
                    </p>
                  </div>
                ) : (
                  <>
                    {messages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
                      >
                        <div
                          className={`max-w-[80%] rounded-lg p-4 ${
                            message.role === 'user'
                              ? 'bg-gradient-to-r from-[#00D8FF] to-[#00FF95] text-white'
                              : 'bg-gray-800 text-gray-100'
                          }`}
                        >
                          <p className="whitespace-pre-wrap">{message.content}</p>
                          {message.role === 'assistant' && (
                            <div className="flex gap-2 mt-2">
                              <button
                                onClick={() => copyMessage(message.content)}
                                className="text-gray-400 hover:text-white transition-colors"
                              >
                                <Copy className="w-4 h-4" />
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                    {loading && (
                      <div className="flex justify-start">
                        <div className="bg-gray-800 rounded-lg p-4">
                          <div className="typing-indicator flex gap-1">
                            <span className="w-2 h-2 bg-gray-400 rounded-full"></span>
                            <span className="w-2 h-2 bg-gray-400 rounded-full"></span>
                            <span className="w-2 h-2 bg-gray-400 rounded-full"></span>
                          </div>
                        </div>
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </>
                )}
              </div>

              {/* Input */}
              <div className="border-t border-gray-800 p-4">
                <form onSubmit={handleSubmit} className="flex gap-2">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Type your message..."
                    disabled={loading}
                    className="flex-1 bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
                  />
                  <Button
                    type="submit"
                    disabled={loading || !input.trim()}
                    variant="gradient"
                  >
                    {loading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Send className="w-4 h-4" />
                    )}
                  </Button>
                </form>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}