# PrimeAI Quick Start Guide

Get PrimeAI running in 10 minutes!

## Prerequisites

- Node.js 18+ installed
- npm or yarn
- Git

## Step 1: Install Dependencies (2 min)

```bash
cd primeai
npm install
```

## Step 2: Set Up Environment (3 min)

```bash
cp .env.example .env
```

Edit `.env` with your credentials:

### Minimum Required (for local testing):

```env
# Database (use local PostgreSQL or Neon free tier)
DATABASE_URL="postgresql://user:password@localhost:5432/primeai"

# Clerk (sign up at clerk.com - free tier available)
NEXT_PUBLIC_CLERK_PUBLISHABLE_KEY=pk_test_xxxxx
CLERK_SECRET_KEY=sk_test_xxxxx

# Stripe (sign up at stripe.com - use test mode)
STRIPE_SECRET_KEY=sk_test_xxxxx
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_xxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxx
STRIPE_PRICE_ID_MONTHLY=price_xxxxx
STRIPE_PRICE_ID_ANNUAL=price_xxxxx

# App
NEXT_PUBLIC_APP_URL=http://localhost:3000
```

## Step 3: Set Up Database (2 min)

```bash
# Generate Prisma client
npx prisma generate

# Create database tables
npx prisma db push
```

## Step 4: Run Development Server (1 min)

```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) 🎉

## Step 5: Test the App (2 min)

1. **Sign Up**: Create an account
2. **Chat**: Send a message in the chat interface
3. **Check Usage**: View your remaining free messages
4. **Test Upgrade**: Try the upgrade flow (use Stripe test card: 4242 4242 4242 4242)

## Quick Service Setup

### Clerk (Authentication)

1. Go to [clerk.com](https://clerk.com)
2. Create free account
3. Create new application
4. Enable Email + Google OAuth
5. Copy API keys to `.env`

### Stripe (Payments)

1. Go to [stripe.com](https://stripe.com)
2. Create free account
3. Switch to Test mode
4. Create two products:
   - Monthly: $19/month
   - Annual: $190/year
5. Copy Price IDs to `.env`
6. For webhooks (local testing):
   ```bash
   stripe listen --forward-to localhost:3000/api/webhooks/stripe
   ```

### Neon (Database)

1. Go to [neon.tech](https://neon.tech)
2. Create free account
3. Create new project
4. Copy connection string to `.env`

## Troubleshooting

### "Module not found" errors
```bash
rm -rf node_modules package-lock.json
npm install
```

### Database connection errors
```bash
# Check DATABASE_URL format
# Ensure database is running
npx prisma db push
```

### Clerk authentication not working
```bash
# Verify API keys in .env
# Check Clerk dashboard settings
```

### Build errors
```bash
npm run build
# Check error messages
```

## Next Steps

1. **Customize branding** - Update colors in `tailwind.config.ts`
2. **Add real AI** - Replace mock AI in `app/api/chat/route.ts`
3. **Deploy** - Follow `DEPLOYMENT_GUIDE.md`
4. **Launch** - Use marketing materials in `/marketing`

## Need Help?

- Check `README.md` for detailed documentation
- Review `STRIPE_SETUP_GUIDE.md` for Stripe configuration
- See `DEPLOYMENT_GUIDE.md` for production deployment

## Test Cards (Stripe Test Mode)

**Success:**
- Card: 4242 4242 4242 4242
- Expiry: Any future date
- CVC: Any 3 digits

**Decline:**
- Card: 4000 0000 0000 0002

**3D Secure:**
- Card: 4000 0025 0000 3155

---

**You're all set! Start building with PrimeAI 🚀**