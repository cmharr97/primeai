# Stripe Setup Guide for PrimeAI

This guide will walk you through setting up Stripe for PrimeAI's subscription system.

## Prerequisites

- Stripe account (sign up at [stripe.com](https://stripe.com))
- PrimeAI application deployed or running locally
- Access to your `.env` file

## Step 1: Create Stripe Account

1. Go to [stripe.com](https://stripe.com)
2. Click "Start now" to create an account
3. Complete the registration process
4. Verify your email address

## Step 2: Switch to Test Mode

**Important:** Always start with Test mode for development!

1. In Stripe Dashboard, look for the toggle in the top-right
2. Switch to "Test mode"
3. You'll see "TEST DATA" banner when in test mode

## Step 3: Get API Keys

1. Go to **Developers** → **API keys**
2. Copy your keys:
   - **Publishable key** (starts with `pk_test_`)
   - **Secret key** (starts with `sk_test_`)

3. Add to your `.env` file:
```env
STRIPE_SECRET_KEY=sk_test_xxxxx
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_xxxxx
```

## Step 4: Create Products

### Create Monthly Product

1. Go to **Products** → **Add product**
2. Fill in details:
   - **Name:** PrimeAI Pro Monthly
   - **Description:** Unlimited AI messages, priority support
   - **Pricing model:** Standard pricing
   - **Price:** $19.00 USD
   - **Billing period:** Monthly
   - **Recurring:** Yes

3. Click **Save product**
4. Copy the **Price ID** (starts with `price_`)
5. Add to `.env`:
```env
STRIPE_PRICE_ID_MONTHLY=price_xxxxx
```

### Create Annual Product

1. Go to **Products** → **Add product**
2. Fill in details:
   - **Name:** PrimeAI Pro Annual
   - **Description:** Unlimited AI messages, priority support, save $38/year
   - **Pricing model:** Standard pricing
   - **Price:** $190.00 USD
   - **Billing period:** Yearly
   - **Recurring:** Yes

3. Click **Save product**
4. Copy the **Price ID** (starts with `price_`)
5. Add to `.env`:
```env
STRIPE_PRICE_ID_ANNUAL=price_xxxxx
```

## Step 5: Set Up Webhooks

Webhooks allow Stripe to notify your app about subscription events.

### For Local Development (Using Stripe CLI)

1. Install Stripe CLI:
```bash
# macOS
brew install stripe/stripe-cli/stripe

# Windows
scoop install stripe

# Linux
wget https://github.com/stripe/stripe-cli/releases/download/v1.19.0/stripe_1.19.0_linux_x86_64.tar.gz
tar -xvf stripe_1.19.0_linux_x86_64.tar.gz
```

2. Login to Stripe:
```bash
stripe login
```

3. Forward webhooks to local server:
```bash
stripe listen --forward-to localhost:3000/api/webhooks/stripe
```

4. Copy the webhook signing secret (starts with `whsec_`)
5. Add to `.env`:
```env
STRIPE_WEBHOOK_SECRET=whsec_xxxxx
```

### For Production

1. Go to **Developers** → **Webhooks**
2. Click **Add endpoint**
3. Enter your endpoint URL:
   ```
   https://your-domain.com/api/webhooks/stripe
   ```

4. Select events to listen for:
   - `checkout.session.completed`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`

5. Click **Add endpoint**
6. Copy the **Signing secret** (starts with `whsec_`)
7. Add to production `.env`:
```env
STRIPE_WEBHOOK_SECRET=whsec_xxxxx
```

## Step 6: Configure Customer Portal

The Customer Portal allows users to manage their subscriptions.

1. Go to **Settings** → **Billing** → **Customer portal**
2. Click **Activate test link** (or **Activate** for production)
3. Configure settings:

### Functionality
- ✅ **Update payment method**
- ✅ **Update billing information**
- ✅ **View invoice history**
- ✅ **Cancel subscription**

### Business Information
- **Business name:** PrimeAI
- **Support email:** support@primeai.app
- **Support phone:** (optional)
- **Privacy policy:** https://primeai.app/privacy
- **Terms of service:** https://primeai.app/terms

### Cancellation
- **Cancellation behavior:** Cancel at period end
- **Cancellation reasons:** (enable all)
- **Retention offers:** (optional - set up later)

### Return URL
```
https://your-domain.com/app/settings
```

4. Click **Save**

## Step 7: Test the Integration

### Test Cards

Use these test cards in Test mode:

**Successful Payment:**
```
Card number: 4242 4242 4242 4242
Expiry: Any future date
CVC: Any 3 digits
ZIP: Any 5 digits
```

**Requires Authentication (3D Secure):**
```
Card number: 4000 0025 0000 3155
```

**Declined Card:**
```
Card number: 4000 0000 0000 0002
```

### Testing Checklist

1. **Sign up for account**
   - [ ] Create new account in PrimeAI
   - [ ] Verify email works

2. **Test checkout flow**
   - [ ] Click "Upgrade to Pro"
   - [ ] Select Monthly plan
   - [ ] Enter test card: 4242 4242 4242 4242
   - [ ] Complete checkout
   - [ ] Verify redirect to success page

3. **Verify subscription created**
   - [ ] Check Stripe Dashboard → Customers
   - [ ] Verify customer created
   - [ ] Verify subscription active
   - [ ] Check subscription details

4. **Test webhook**
   - [ ] Verify webhook received in Stripe Dashboard
   - [ ] Check your app logs
   - [ ] Verify database updated (subscription status = "active")

5. **Test app functionality**
   - [ ] Send unlimited messages (should work)
   - [ ] Check settings page (should show "Pro" plan)
   - [ ] Verify usage shows "Unlimited"

6. **Test Customer Portal**
   - [ ] Go to Settings → Manage Billing
   - [ ] Verify portal opens
   - [ ] Try updating payment method
   - [ ] Try canceling subscription
   - [ ] Verify cancellation works

7. **Test subscription lifecycle**
   - [ ] Cancel subscription
   - [ ] Verify status changes to "canceled"
   - [ ] Verify access continues until period end
   - [ ] Verify access removed after period end

## Step 8: Go Live

When ready for production:

### 1. Switch to Live Mode

1. In Stripe Dashboard, toggle to **Live mode**
2. Complete account activation:
   - Verify business details
   - Add bank account for payouts
   - Complete identity verification

### 2. Get Live API Keys

1. Go to **Developers** → **API keys**
2. Copy your live keys:
   - Publishable key (starts with `pk_live_`)
   - Secret key (starts with `sk_live_`)

3. Update production `.env`:
```env
STRIPE_SECRET_KEY=sk_live_xxxxx
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_live_xxxxx
```

### 3. Create Live Products

Repeat Step 4 in Live mode to create:
- Monthly product ($19/month)
- Annual product ($190/year)

Update `.env` with live Price IDs.

### 4. Set Up Live Webhooks

Repeat Step 5 for production:
1. Add webhook endpoint with your production URL
2. Select same events
3. Copy live webhook secret
4. Update production `.env`

### 5. Activate Live Customer Portal

Repeat Step 6 in Live mode.

### 6. Test in Production

Run through the testing checklist again with real cards (or test cards in live mode).

## Troubleshooting

### Webhook Not Receiving Events

**Check:**
1. Webhook URL is correct and accessible
2. Webhook secret matches in `.env`
3. Events are selected in Stripe Dashboard
4. Check Stripe Dashboard → Webhooks → Attempts for errors

**Debug:**
```bash
# View webhook logs
stripe logs tail

# Test webhook locally
stripe trigger checkout.session.completed
```

### Checkout Session Not Creating

**Check:**
1. API keys are correct
2. Price IDs are correct
3. Customer email is valid
4. Check browser console for errors
5. Check server logs

### Subscription Not Updating in Database

**Check:**
1. Webhook is receiving events
2. Webhook signature verification passes
3. Database connection is working
4. Check server logs for errors

**Debug:**
```typescript
// Add logging to webhook handler
console.log('Webhook event:', event.type)
console.log('Webhook data:', event.data.object)
```

### Customer Portal Not Opening

**Check:**
1. Customer has a Stripe customer ID
2. Customer Portal is activated
3. Return URL is correct
4. API keys are correct

## Security Best Practices

1. **Never expose secret keys**
   - Keep `STRIPE_SECRET_KEY` server-side only
   - Only use `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` client-side

2. **Always verify webhook signatures**
   - Use `stripe.webhooks.constructEvent()`
   - Never trust webhook data without verification

3. **Use HTTPS in production**
   - Stripe requires HTTPS for webhooks
   - Vercel provides HTTPS automatically

4. **Rotate keys if compromised**
   - Generate new keys in Stripe Dashboard
   - Update all environments immediately

5. **Monitor webhook failures**
   - Set up alerts in Stripe Dashboard
   - Check webhook logs regularly

## Monitoring and Analytics

### Stripe Dashboard

Monitor these metrics:
- **Revenue:** Track MRR and total revenue
- **Customers:** Active, churned, new
- **Subscriptions:** Active, canceled, past due
- **Failed payments:** Monitor and retry

### Set Up Alerts

1. Go to **Settings** → **Notifications**
2. Enable alerts for:
   - Failed payments
   - Successful payments
   - Subscription cancellations
   - Disputes

### Export Data

1. Go to **Reports**
2. Create custom reports for:
   - Revenue analysis
   - Customer lifetime value
   - Churn rate
   - Payment success rate

## Advanced Features

### Coupons and Discounts

1. Go to **Products** → **Coupons**
2. Create coupon:
   - **Name:** LAUNCH50
   - **Discount:** 50% off
   - **Duration:** 3 months
   - **Redemption limit:** 100

3. Apply in checkout:
```typescript
const session = await stripe.checkout.sessions.create({
  // ... other params
  discounts: [{
    coupon: 'LAUNCH50',
  }],
})
```

### Metered Billing (Future)

For usage-based pricing:
1. Create product with metered billing
2. Report usage via API
3. Charge based on actual usage

### Tax Collection

1. Go to **Settings** → **Tax**
2. Enable automatic tax collection
3. Configure tax rates by location

## Support Resources

- **Stripe Documentation:** [stripe.com/docs](https://stripe.com/docs)
- **Stripe Support:** [support.stripe.com](https://support.stripe.com)
- **API Reference:** [stripe.com/docs/api](https://stripe.com/docs/api)
- **Webhook Events:** [stripe.com/docs/api/events](https://stripe.com/docs/api/events)

## Checklist Summary

- [ ] Create Stripe account
- [ ] Switch to Test mode
- [ ] Get API keys
- [ ] Create Monthly product ($19/month)
- [ ] Create Annual product ($190/year)
- [ ] Set up webhooks (local or production)
- [ ] Configure Customer Portal
- [ ] Test checkout flow
- [ ] Test webhook events
- [ ] Test subscription management
- [ ] Go live (when ready)
- [ ] Set up monitoring and alerts

---

**Need Help?**

If you encounter issues:
1. Check Stripe Dashboard logs
2. Review webhook attempts
3. Check server logs
4. Contact Stripe support
5. Review this guide again

**Last Updated:** 2025